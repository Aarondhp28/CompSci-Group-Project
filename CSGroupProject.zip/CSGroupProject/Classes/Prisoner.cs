﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSGroupProject
{
    public class Prisoner
    {
        public bool Violent { set; get; }
        public int IDNumber { set; get; }
        public string FirstName { set; get; }
        public string LastName { set; get; }
        public int Age { set; get; }
        public int SentenceMonths { set; get; }

        public Prisoner() { }
        public Prisoner(int idNum, string fName, string lName, int age, int sentence, bool violent)
        {
            this.FirstName = fName;
            this.LastName = lName;
            this.Age = age;
            this.Violent = violent;
            this.SentenceMonths = sentence;

        }

        public override string ToString()
        {
            string info="";
            info += $"ID: {IDNumber} {FirstName} {LastName}";
            return info;
        }

    }
}
