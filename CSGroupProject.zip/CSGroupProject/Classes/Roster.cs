﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSGroupProject
{
    public class Roster : IEnumerable
    {
        public List<Prisoner> Prisoners = new List<Prisoner>();
        public List<Prisoner> AddPrisonerToRoster(Prisoner pri)
        {
            Prisoners.Add(pri);
            return Prisoners;
        }
        public string RemovePrisonerFromRoster(List<Prisoner> list, int idNum)
        {
            foreach (Prisoner pri in list)
            {
                if (pri.IDNumber == idNum)
                {
                    list.Remove(pri);
                    return $"{pri.FirstName} {pri.LastName} was removed from the system.";
                }    
            }
            return "No prisoner found with that identification number.";
        }

        public override string ToString()
        {
            foreach (Prisoner pri in Prisoners)
            {
                return $"ID: {pri.IDNumber} {pri.FirstName} {pri.LastName}";
            }
            return "The list remains empty.";
        }
        public IEnumerator GetEnumerator()
        {
            return Prisoners.GetEnumerator();
        }
    }
}
