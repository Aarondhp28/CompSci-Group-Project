﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSGroupProject
{
    public class RosterView
    {
        public Roster Roster { set; get; } = new Roster();

        public RosterView(Roster r)
        {

            this.Roster = r;
            //Given a roster, assigns it to the this.roster field. 
            //(Throw an error if the passed roster is null.)

        }
            
	public string Show(List<Prisoner> list)
        {
            // Returns a string representation of the roster object.
            string prisonerInfo = null;
            if (list.Count == 0)
            {
                prisonerInfo = "List remains empty";
            }
            else if (list.Count > 0)
            {
                foreach (var prisoner in list)
                {
                    prisonerInfo += $"ID: {prisoner.IDNumber}, {prisoner.FirstName} {prisoner.LastName}\n";
                }
            }

            return prisonerInfo;
        }
    }
}
