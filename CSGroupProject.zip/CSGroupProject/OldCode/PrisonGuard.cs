﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupProject{
    class PrisonerGuard{
        public string guardName { get; private set; }
        public string guardShift { get; private set; }
        public string guardRank { get; private set; }

        public PrisonerGuard(string guardRank, string guardName, string guardShift){
            this.guardName = guardName;
            this.guardShift = guardShift;
            this.guardRank = guardRank;

            if (guardRank.Length <= 0)
                throw new ArgumentException("Guard Rank cannot be empty");

            if (guardName.Length <= 0)
                throw new ArgumentException("Guard Name cannot be empty.");
        }
        public override string ToString(){
            return $"{guardRank} {guardName} on the {guardShift}";
        }
    }
}
