﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GroupProject
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<PrisonerGuard> PrisonerGuardsList;
        public MainWindow(){
            InitializeComponent();
            PrisonerGuardsList = new List<PrisonerGuard>();
        }
        private void AddGuardClick(object sender, RoutedEventArgs e){
            PrisonerGuard morningGuard = new PrisonerGuard(GuardRankDispaly.Text, GuardNameDispaly.Text, 
                MorningShiftButton.Content.ToString().ToLower());
            PrisonerGuard afternoonGuard = new PrisonerGuard(GuardRankDispaly.Text, GuardNameDispaly.Text,
                AfternoonShiftButton.Content.ToString().ToLower());
            PrisonerGuard nightGuard = new PrisonerGuard(GuardRankDispaly.Text, GuardNameDispaly.Text,
               NightShiftButton.Content.ToString().ToLower());

            string msgTxt = "Do you want to add this guard?";
            string titleTxt = "Add Guard";
            MessageBoxButton button = MessageBoxButton.YesNo;
            MessageBoxResult result = MessageBox.Show(msgTxt, titleTxt, button);

            switch (result){
                case MessageBoxResult.Yes:
                    if (MorningShiftButton.IsChecked == false
                        && AfternoonShiftButton.IsChecked == false && NightShiftButton.IsChecked == false)
                        MessageBox.Show("Error! Shift must be selected.");

                    if (MorningShiftButton.IsChecked == true){
                        PrisonerGuardsList.Add(morningGuard);
                        GuardDisplayBox.Items.Add(morningGuard);
                    }

                    if(AfternoonShiftButton.IsChecked == true){
                        PrisonerGuardsList.Add(afternoonGuard);
                        GuardDisplayBox.Items.Add(afternoonGuard);
                    }

                    if (NightShiftButton.IsChecked == true){
                        PrisonerGuardsList.Add(nightGuard);
                        GuardDisplayBox.Items.Add(nightGuard);
                    }
                    break;
                case MessageBoxResult.No:
                    break;
            }
        }
        private void RemoveGuardClick(object sender, RoutedEventArgs e){
            string msgTxt = "Do you want to remove this guard?";
            string titleTxt = "Remove Guard";
            MessageBoxButton button = MessageBoxButton.YesNo;
            MessageBoxResult result = MessageBox.Show(msgTxt, titleTxt, button);

            switch (result){
                case MessageBoxResult.Yes:
                    for(int i = 0; i < PrisonerGuardsList.Count; i++){
                        if (GuardRemovalDisplay.Text == PrisonerGuardsList[i].guardName){
                            PrisonerGuardsList.RemoveAt(i);
                            GuardDisplayBox.Items.RemoveAt(i);
                            break;
                        }
                        else if (GuardRemovalDisplay.Text != PrisonerGuardsList[i].guardName){
                            MessageBox.Show("Error! No guard with name in display.");
                        }
                    }
                    break;
                case MessageBoxResult.No:
                    break;
            }
        }
        private void ClearGuardsClick(object sender, RoutedEventArgs e){
            string msgTxt = "Do you want to clear all guards?";
            string titleTxt = "Clear Guards";
            MessageBoxButton button = MessageBoxButton.YesNo;
            MessageBoxResult result = MessageBox.Show(msgTxt, titleTxt, button);

            switch (result){
                case MessageBoxResult.Yes:
                    PrisonerGuardsList.Clear();
                    GuardDisplayBox.Items.Clear();
                    break;
                case MessageBoxResult.No:
                    break;
            }
        }
    }
}