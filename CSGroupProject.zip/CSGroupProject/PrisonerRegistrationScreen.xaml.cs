﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CSGroupProject
{
    /// <summary>
    /// Interaction logic for PrisonerRegistrationScreen.xaml
    /// </summary>
    public partial class PrisonerRegistrationScreen : Window
    {
        Roster Roster { set; get; } = new Roster();
        RosterView RV { set; get; }
        public PrisonerRegistrationScreen()
        {
            InitializeComponent();
            RV = new RosterView(Roster);

            Image mugshot = new Image();
            BitmapImage bitmapMugshot = new BitmapImage();
            bitmapMugshot.BeginInit();
            bitmapMugshot.UriSource = new Uri(@"C:\Users\Aaron D\source\repos\GroupProjectPrisonerReg\GroupProjectPrisonerReg\mugshotDefault.jpg", UriKind.Relative);
            bitmapMugshot.EndInit();
            mugshot.Stretch = Stretch.Fill;
            mugshot.Source = bitmapMugshot;
        }


        public bool IsDigitsOnly(string s)
        {
            foreach (char c in s)
            {
                if (c > 0 || c < 9)
                {
                    return true;
                }
            }
            return false;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            RV = new RosterView(Roster);
            bool idNumInUse = false;


            //Checks to see if all fields have been left empty.
            if (string.IsNullOrWhiteSpace(IDNumBox.Text)
                || string.IsNullOrWhiteSpace(fNameBox.Text)
                || string.IsNullOrWhiteSpace(lNameBox.Text)
                || string.IsNullOrWhiteSpace(ageBox.Text)
                || IsDigitsOnly(IDNumBox.Text) != true
                || IsDigitsOnly(ageBox.Text) != true
                || IsDigitsOnly(sentMBox.Text) != true)
            {
                MessageBox.Show("Please fill out all fields with appropriate information.", "Illegal Entry Detected");
            }
            else
            {
                //Converts user data into the proper format for the prisoner class. 
                int iDSI = Convert.ToInt32(IDNumBox.Text);
                string fnSI = fNameBox.Text;
                string lnSI = lNameBox.Text;
                int aSI = Convert.ToInt32(ageBox.Text);
                int sentSI = Convert.ToInt32(ageBox.Text);

                //creates a new prisoner object with the data provided above.
                Prisoner prisoner = new Prisoner(iDSI, fnSI, lnSI, aSI, sentSI, true);

                //Checks for duplicate use of an id number.
                //If no duplicates are found, adds the new prisoner object to the roster.
                foreach (Prisoner pri in Roster)
                {
                    if (pri.IDNumber == iDSI)
                    {
                        MessageBox.Show("Error. A prisoner with this identification number already exists.");
                        idNumInUse = true;
                    }
                }
                if (idNumInUse == false)
                {
                    Roster.AddPrisonerToRoster(prisoner);
                }

                //Databinds the RosterView to the text box which will display the rosterview. 
                TextBox tb = rosterViewBox;
                Binding b = new Binding
                {
                    Mode = BindingMode.OneWay,
                    Source = RV.Show(Roster.Prisoners)
                };
                tb.SetBinding(TextBox.TextProperty, b);
            }


        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            //Checks to see if a student ID Number exists in the roster.
            //If it returns true, it removes the student from the roster.

            bool idNumInUse = false;

            int iDSI = Convert.ToInt32(IDNumBox.Text);

            foreach (Prisoner pri in Roster)
            {
                if (pri.IDNumber == iDSI)
                {
                    idNumInUse = true;
                }
            }

            if (idNumInUse == true)
            {
                MessageBox.Show(RV.Roster.RemovePrisonerFromRoster(Roster.Prisoners, Convert.ToInt32(iDSI)));
            }
            else
                MessageBox.Show("No prisoner found with that ID Number.");

            //Databinds the RosterView to the text box which will display the rosterview.
            TextBox tb = rosterViewBox;
            Binding b = new Binding
            {
                Mode = BindingMode.OneWay,
                Source = RV.Show(Roster.Prisoners)
            };
            tb.SetBinding(TextBox.TextProperty, b);

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            mgsht.Source = new BitmapImage(new Uri(@"C:\Users\Aaron D\source\repos\GroupProjectPrisonerReg\GroupProjectPrisonerReg\Joker.jpg"));
            mgsht.Stretch = Stretch.UniformToFill;
            //Display Mugshot

            //Update Rosterview with their bio.

        }
    }
}
