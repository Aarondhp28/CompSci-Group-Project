﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace _3005GrpProj
{
    class LoginPage
    {
        private string userUsername; //username for login function
        private string userPassword; //password for login function

        //logging the default background color for the alarm function
        private System.Windows.Media.Brush mainBackgroundColor = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(161, 161, 161));

        //Default constructor initializing the username and password
        public LoginPage()
        {
            userUsername = "Warden";
            userPassword = "Comp$ci3005";
        }

        //function to check the information given in the username and password fields
        public bool CheckInfo(string userEnteredUsername, string userEnteredPassword, MainWindow login)
        {
            try
            {
                //if the username and password are correct, grant access to the registry
                if (userEnteredUsername == userUsername && userEnteredPassword == userPassword)
                {
                    PersonnelRegistrationScreen window = new PersonnelRegistrationScreen();
                    window.Show();
                    return true;
                }
                //else if it is a prisoner attempting to login, set off an alarm
                else if (userEnteredUsername == /*anyone in list of prisoners*/"gary")
                {
                    Alarm(login);
                    return false;
                }
                //else one of the fields were incorrect, report to user
                else
                {
                    throw new ArgumentException("Error: The username or the password are incorrect, please try again.");
                }
            }
            catch (ArgumentException e)
            {
                MessageBox.Show(e.Message); //display the error message
                return false;
            }
        }

        //When a prisoner attempts to log into the registry system
        private void Alarm(MainWindow login)
        {
            login.alarmJailCell.Visibility = Visibility.Visible;    //alarm jail cell image is turned on
            login.Background = System.Windows.Media.Brushes.Red;    //background is turned to bright red
            login.alarmRESET.Visibility = Visibility.Visible;       //the button to reset the alarm is turned on
            login.closeProgram.Visibility = Visibility.Hidden;      //the ability to close the program is disabled
        }

        //When the button to reset the alarm is selected
        public void ResetAlarm(MainWindow login)
        {
            login.usernameBox.Text = "";                            //reset text in username field
            login.passwordTextBox.Password = "";                    //reset text in password field
            login.alarmJailCell.Visibility = Visibility.Hidden;     //jail image is turned off
            login.Background = mainBackgroundColor;                 //background color is restored
            login.alarmRESET.Visibility = Visibility.Hidden;        //the button to reset alarm is turned off
            login.closeProgram.Visibility = Visibility.Visible;     //the ability to close the program is restored
        }
    }
}
