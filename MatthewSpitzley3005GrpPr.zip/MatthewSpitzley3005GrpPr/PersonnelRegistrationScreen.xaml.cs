﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _3005GrpProj
{
    /// <summary>
    /// Interaction logic for PersonnelRegistrationScreen.xaml
    /// </summary>
    public partial class PersonnelRegistrationScreen : Window
    {
        //default constructor making sure neither image starts as visible
        public PersonnelRegistrationScreen()
        {
            InitializeComponent();
            guardPreviewImage.Visibility = Visibility.Hidden;
            prisonerPreviewImage.Visibility = Visibility.Hidden;
        }

        //if the prisoner radio button is selected the prisoner preview image is displayed
        private void prisonerButtonChecked(object sender, RoutedEventArgs e)
        {
            guardPreviewImage.Visibility = Visibility.Hidden;
            prisonerPreviewImage.Visibility = Visibility.Visible;
        }

        //if the guard radio button is selected the guard preview image is displayed
        private void guardButtonChecked(object sender, RoutedEventArgs e)
        {
            prisonerPreviewImage.Visibility = Visibility.Hidden;
            guardPreviewImage.Visibility = Visibility.Visible;
        }

        private void Next_Click(object sender, RoutedEventArgs e)
        {
            if (prisonerButton.IsChecked.Value)
            {
                //Prisoner (screen/window/page) = new Prisoner();
                //(screen/window/page).Show();
                this.Close();
            }
            else if(guardButton.IsChecked.Value)
            {
                //Guard (screen/window/page) = new Guard();
                //(screen/window/page).Show();
                this.Close();
            }
        }

        //brings the user back to the login window
        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow window = new MainWindow();
            window.Show();
            this.Close();
        }

        //closes the program
        private void Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
